using demo_part2.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Diagnostics;

namespace demo_part2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                connection conn = new connection();
                using (SqlConnection connect = new SqlConnection(conn.connecting()))
                {
                    connect.Open();
                    Console.Write("Connected");
                    connect.Close();
                }
            }
            catch (IOException error)
            {
                Console.WriteLine("Error: " + error.Message);
            }

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public IActionResult Register_user(register add_user)
        {
            string name = add_user.username;
            string email = add_user.email;
            string password = add_user.password;
            string role = add_user.role;

            string message = add_user.insert_user(name, email, role, password);

            if (message == "done")
            {
                return RedirectToAction("Login", "Home");
            }
            else
            {
                Console.WriteLine(message);
                return RedirectToAction("Index", "Home");
            }
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult login_user(check_login user)
        {
            string email = user.email;
            string role = user.role;
            string password = user.password;

            // Assuming login_user method returns a user object or ID when successful
            var userId = user.login_user(email, role, password);

            if (userId != null)
            {
                HttpContext.Session.SetString("UserId", userId); // Save user ID to session
                HttpContext.Session.SetString("UserRole", role);
                return RedirectToAction("Dashboard", "Home");
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }

        public IActionResult Dashboard()
        {
            var userRole = HttpContext.Session.GetString("UserRole");
            ViewData["UserRole"] = userRole;
            return View();
        }

        [HttpPost]
        public IActionResult claim_sub(IFormFile file, claim insert)
        {
            string module_name = insert.user_email; // Or however you get the user email
            string hour_work = insert.hours_worked;
            string hour_rate = insert.hour_rate;
            string description = insert.description;

            // Get the user ID from session
            var userId = HttpContext.Session.GetString("UserId"); // Make sure to set this during login
            if (userId == null)
            {
                // Handle the case where userId is not set (e.g., redirect to login)
                return RedirectToAction("Login", "Home");
            }

            // Set the user_id in the claim object
            insert.user_id = userId; // Ensure user_id is set before insertion

            string filename = "no file";
            if (file != null && file.Length > 0)
            {
                filename = Path.GetFileName(file.FileName);
                string folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/pdf");

                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                string filePath = Path.Combine(folderPath, filename);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }
            }

            string message = insert.insert_claim(module_name, hour_work, hour_rate, description, filename);

            if (message == "done")
            {
                Console.WriteLine(message);
                return RedirectToAction("Dashboard", "Home");
            }
            else
            {
                Console.WriteLine(message);
                return RedirectToAction("Dashboard", "Home");
            }
        }

        // Open claims
        public IActionResult view_claims()
        {
            get_claims userClaims = new get_claims();
            return View(userClaims);
        }

        public IActionResult Approve()
        {
            List<review_claim> claims = review_claim.GetAllClaims();
            return View(claims);
        }

        public IActionResult ApproveClaim(int id)
        {
            review_claim.UpdateClaimStatus(id, "Approved");
            return RedirectToAction("Approve");
        }

        public IActionResult RejectClaim(int id)
        {
            review_claim.UpdateClaimStatus(id, "Rejected");
            return RedirectToAction("Approve");
        }

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Login", "Home");
        }

    }
}
