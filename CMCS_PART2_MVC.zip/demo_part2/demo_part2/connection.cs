﻿namespace demo_part2
{
    public class connection
    {
        // return connection method
        public string connecting()
        {
            //then return the connection
            return "Data Source=(localdb)\\demo_p2;Initial Catalog=demo_db;";
        }
    }
}
