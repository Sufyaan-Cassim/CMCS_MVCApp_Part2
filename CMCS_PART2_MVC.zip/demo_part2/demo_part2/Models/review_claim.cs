﻿using System.Collections.Generic;
using System.Data.SqlClient;

namespace demo_part2.Models
{
    public class review_claim
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Module { get; set; }
        public string UserId { get; set; }
        public string Hours { get; set; }
        public string Rate { get; set; }
        public string Note { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string Total { get; set; }
        public string Status { get; set; }

        // Method to fetch all claims from the database
        public static List<review_claim> GetAllClaims()
        {
            List<review_claim> claims = new List<review_claim>();
            connection conn = new connection();

            using (SqlConnection connect = new SqlConnection(conn.connecting()))
            {
                connect.Open();
                string query = "SELECT * FROM claiming"; // Select all claims without filtering

                using (SqlCommand cmd = new SqlCommand(query, connect))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            claims.Add(new review_claim
                            {
                                Id = (int)reader["id"],
                                Email = (string)reader["email"],
                                Module = (string)reader["module"],
                                UserId = (string)reader["user_id"],
                                Hours = (string)reader["hours"],
                                Rate = (string)reader["rate"],
                                Note = (string)reader["note"],
                                FileName = (string)reader["file_name"],
                                FilePath = (string)reader["file_path"],
                                Total = (string)reader["total"],
                                Status = (string)reader["status"]
                            });
                        }
                    }
                }
            }

            return claims;
        }

        // Method to update the claim status in the database
        public static void UpdateClaimStatus(int id, string status)
        {
            connection conn = new connection();

            using (SqlConnection connect = new SqlConnection(conn.connecting()))
            {
                connect.Open();
                string query = "UPDATE claiming SET status = @status WHERE id = @id";

                using (SqlCommand command = new SqlCommand(query, connect))
                {
                    command.Parameters.AddWithValue("@status", status.ToLower());
                    command.Parameters.AddWithValue("@id", id);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
