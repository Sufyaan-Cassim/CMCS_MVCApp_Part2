﻿using System.Collections;
using System.Data.SqlClient;

namespace demo_part2.Models
{
    public class get_claims
    {
        public List<string> email { get; set; } = new List<string>();
        public List<string> module { get; set; } = new List<string>();
        public List<string> id { get; set; } = new List<string>();
        public List<string> hours { get; set; } = new List<string>();
        public List<string> rate { get; set; } = new List<string>();
        public List<string> note { get; set; } = new List<string>();
        public List<string> total { get; set; } = new List<string>();
        public List<string> status { get; set; } = new List<string>();
        public List<string> file_name { get; set; } = new List<string>();
        public List<string> file_path { get; set; } = new List<string>();

        connection connect = new connection();

        // Constructor
        public get_claims()
        {
            string emails = gets_email(); // Get the current user's email

            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    connects.Open();

                    using (SqlCommand prepare = new SqlCommand("SELECT * FROM claiming WHERE email = @Email;", connects))
                    {
                        prepare.Parameters.AddWithValue("@Email", emails); // Use parameterized query

                        using (SqlDataReader getemail = prepare.ExecuteReader())
                        {
                            if (getemail.HasRows)
                            {
                                while (getemail.Read())
                                {
                                    email.Add(getemail["email"].ToString()); // Retrieve email
                                    module.Add(getemail["module"].ToString());
                                    id.Add(getemail["user_id"].ToString()); // Use user_id correctly
                                    hours.Add(getemail["hours"].ToString());
                                    rate.Add(getemail["rate"].ToString());
                                    note.Add(getemail["note"].ToString());
                                    total.Add(getemail["total"].ToString());
                                    status.Add(getemail["status"].ToString());
                                    file_name.Add(getemail["file_name"].ToString());
                                    file_path.Add(getemail["file_path"].ToString());
                                }
                            }

                            getemail.Close();
                        }
                    }

                    connects.Close();
                }
            }
            catch (IOException error)
            {
                Console.WriteLine(error.Message);
            }
        }

        public string gets_email()
        {
            string hold_email = "";

            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    connects.Open();

                    using (SqlCommand prepare = new SqlCommand("SELECT * FROM active", connects))
                    {
                        using (SqlDataReader getemail = prepare.ExecuteReader())
                        {
                            if (getemail.HasRows)
                            {
                                while (getemail.Read())
                                {
                                    hold_email = getemail["email"].ToString(); // Fetch email correctly
                                }
                            }

                            getemail.Close();
                        }
                    }

                    connects.Close();
                }
            }
            catch (IOException error)
            {
                Console.WriteLine(error.Message);
                hold_email = error.Message;
            }

            return hold_email;
        }
    }
}
