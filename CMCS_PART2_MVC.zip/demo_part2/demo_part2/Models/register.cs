﻿using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace demo_part2.Models
{
    public class register
    {

        //getter and setter for the user info collection
        [Required(ErrorMessage = "Name is required.")]
        public string username { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email format.")]
        public string email { get; set; }

        [Required(ErrorMessage = "Role selection is required.")]
        public string role { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [StringLength(100, ErrorMessage = "Password must be at least {2} characters long.", MinimumLength = 6)]
        public string password { get; set; }

        //connection string class
        connection connect = new connection();

        public string insert_user(string name, string emails, string roles, string password)
        {

            //temp var for message
            string message = "";

            //connect to database
            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    //query
                    connects.Open();

                    //query
                    string query = "INSERT INTO users VALUES('"+name+"', '"+emails+"', '"+roles+"', '"+password+"');";

                    //execute command
                    using (SqlCommand add_new_user = new SqlCommand(query, connects))
                    {
                        //then execute it
                        add_new_user.ExecuteNonQuery();

                        //assign the message
                        message = "done";

                    }   
                    //then close connection
                    connects.Close();
                }
            }
            catch (IOException error)
            {
                //return the error
                message = error.Message;
                
            }

            return message;
        }

    }
}
