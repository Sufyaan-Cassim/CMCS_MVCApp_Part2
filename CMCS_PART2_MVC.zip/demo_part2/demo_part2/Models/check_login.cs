﻿using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace demo_part2.Models
{
    public class check_login
    {

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email format.")]
        public string email { get; set; }

        [Required(ErrorMessage = "Role selection is required.")]
        public string role { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        public string password { get; set; }

        //connection string
        connection connect = new connection();

        //method to check the user
        public string login_user(string emails, string roles, string password)
        {
            //temp message
            string message = "";
            Console.WriteLine(email + " and " + password);
            try
            {
                //connect and open
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    //query
                    connects.Open();

                    //query
                    string query = "SELECT * FROM users WHERE email = '" + emails + "' AND password = '" + password + "';";

                    //execute command
                    using (SqlCommand prepare = new SqlCommand(query, connects))
                    {
                        //then execute it
                        prepare.ExecuteNonQuery();

                        //read the data
                        using (SqlDataReader find_user = prepare.ExecuteReader() )
                        {
                            //then check if the user is found
                            if (find_user.HasRows)
                            {
                                //then assign message
                                message = "found";
                                Console.WriteLine(message);
                            }
                            else
                            {
                                message = "not";
                                Console.WriteLine(message);
                            }
                        } 
                    }

                    connects.Close();
                    if (message == "found")
                    {
                        update_active(emails);
                    }

                }

            }
            catch (IOException erro_db)
            {
                //return the error
                message = erro_db.Message;

            }
            return message;
        }

        //update active method
        public  void update_active(string emails)
        {
            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting() ))
                {
                    connects.Open();

                    string query = "update active set email = '" + email + "'";

                    using (SqlCommand done = new SqlCommand(query, connects))
                    {
                        done.ExecuteNonQuery() ;
                    }

                    connects.Close();
                }

            }
            catch (IOException error)
            {
                Console.WriteLine("error " + error.Message);
                
            }
        }

    }

}
