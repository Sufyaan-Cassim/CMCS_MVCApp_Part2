﻿using System.Data.SqlClient;
using Microsoft.AspNetCore.Http; // Add this for IHttpContextAccessor
using System.IO;

namespace demo_part2.Models
{
    public class claim
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public claim(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public string user_email { get; set; }
        public string user_id { get; set; }
        public string hours_worked { get; set; }
        public string hour_rate { get; set; }
        public string description { get; set; }

        // Connection
        connection connect = new connection();

        public string insert_claim(string module, string hour_worked, string rate, string note, string filename)
        {
            string message = "";

            // Get the user ID from session
            var userId = _httpContextAccessor.HttpContext.Session.GetString("UserId");
            if (userId == null)
            {
                return "User ID not found in session.";
            }

            // Calculate total
            string total = (int.Parse(hour_worked) * int.Parse(rate)).ToString();

            // If a file is uploaded, set the file path
            string file_path = filename != "no file" ? Path.Combine("/pdf", filename) : "none";

            // Use a parameterized query to insert the claim
            string query = "INSERT INTO claiming (email, module, user_id, hours, rate, note, file_name, file_path, total, status) " +
                           "VALUES (@Email, @Module, @UserId, @Hours, @Rate, @Note, @FileName, @FilePath, @Total, 'pending');";

            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    connects.Open();

                    using (SqlCommand done = new SqlCommand(query, connects))
                    {
                        // Add parameters
                        done.Parameters.AddWithValue("@Email", "some_email@example.com"); // Use the actual email if needed
                        done.Parameters.AddWithValue("@Module", module);
                        done.Parameters.AddWithValue("@UserId", userId); // Insert the user ID
                        done.Parameters.AddWithValue("@Hours", hour_worked);
                        done.Parameters.AddWithValue("@Rate", rate);
                        done.Parameters.AddWithValue("@Note", note);
                        done.Parameters.AddWithValue("@Total", total);
                        done.Parameters.AddWithValue("@FileName", filename);
                        done.Parameters.AddWithValue("@FilePath", file_path);

                        done.ExecuteNonQuery();
                        message = "Claim submitted successfully!";
                    }
                }
            }
            catch (IOException error)
            {
                message = error.Message;
            }

            return message;
        }

        public string get_id()
        {
            string hold_id = "";

            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    connects.Open();

                    using (SqlCommand prepare = new SqlCommand("SELECT * FROM active", connects))
                    {
                        using (SqlDataReader getID = prepare.ExecuteReader())
                        {
                            if (getID.HasRows)
                            {
                                while (getID.Read())
                                {
                                    hold_id = getID["ID"].ToString();
                                }
                            }

                            getID.Close();
                        }
                    }

                    connects.Close();
                }
            }
            catch (IOException error)
            {
                Console.WriteLine(error.Message);
                hold_id = error.Message;
            }

            return hold_id;
        }

        public string get_email()
        {
            string hold_email = "";

            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    connects.Open();

                    using (SqlCommand prepare = new SqlCommand("SELECT * FROM active", connects))
                    {
                        using (SqlDataReader getemail = prepare.ExecuteReader())
                        {
                            if (getemail.HasRows)
                            {
                                while (getemail.Read())
                                {
                                    hold_email = getemail["email"].ToString(); // Correctly retrieving the email
                                }
                            }

                            getemail.Close();
                        }
                    }

                    connects.Close();
                }
            }
            catch (IOException error)
            {
                Console.WriteLine(error.Message);
                hold_email = error.Message;
            }

            return hold_email;
        }
    }
}
