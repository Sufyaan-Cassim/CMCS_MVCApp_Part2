using demo_part2.Controllers; // For HomeController
using demo_part2.Models;      // For Claim
using Microsoft.AspNetCore.Http; // For IHttpContextAccessor
using Microsoft.AspNetCore.Mvc; // Needed for ActionResult and Controller
using Microsoft.Extensions.Logging; // For ILogger
using Moq; // For creating mock objects
using Xunit; // For unit testing

namespace demo_part2.tests
{
    public class HomeControllerTests
    {
        private readonly Mock<ILogger<HomeController>> _loggerMock;
        private readonly HomeController _controller;

        public HomeControllerTests()
        {
            _loggerMock = new Mock<ILogger<HomeController>>();
            // Only pass the logger since the controller's constructor only takes ILogger
            _controller = new HomeController(_loggerMock.Object);
        }

        [Fact]
        public void Index_Returns_ViewResult()
        {
            // Act
            var result = _controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.NotNull(viewResult); // Check that the result is not null
        }

        [Fact]
        public void Login_Returns_ViewResult()
        {
            // Act
            var result = _controller.Login();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.NotNull(viewResult);
        }

        [Fact]
        public void Register_user_ValidInput_RedirectsToLogin()
        {
            // Arrange
            var user = new register
            {
                username = "testuser",
                email = "test@example.com",
                password = "password123",
                role = "User"
            };

            // Act
            var result = _controller.Register_user(user);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Login", redirectResult.ActionName);
        }

        [Fact]
        public void Privacy_Returns_ViewResult()
        {
            // Act
            var result = _controller.Privacy();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.NotNull(viewResult);
        }
    }
}
